const form = document.querySelector(".js-fname"),
    input = form.querySelector("input"),
    greeting = document.querySelector(".js-greetings")

const USER_LS = "currentUser"

function writeName(event) {
    console.log("writeNameStart")
    event.preventDefault();
    const curretValue = input.value;
    paintGreeting(curretValue);
    // const currentValue = input.value;
    // paintGreeting(currentValue);
    // console.loadName(asd)
    console.log("writeNameEnd")
}

function askForName() {
    console.log("askForNameStart")
    form.addEventListener("submit", writeName)
    console.log("askForNameEnd")
}

function paintGreeting(text) {
    console.log("paintGreetingFunction")
    greeting.innerText = `Hello ${text}`
}

function loadName() {
    const currentUser = localStorage.getItem("currentUser")
    if (currentUser === null) {
        askForName();
    } else {
        // 값이 있을 경우
    }
}















function init() {
    loadName();
}

init();