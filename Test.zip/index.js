const form = document.querySelector(".js-fname")
const input = form.querySelector("input")

const USER_LS = "currentUser"

function writeName(event){
    event.preventDefault();
}

function askForName() {
    form.addEventListener("submit,", writeName)
}

function loadName(){
    const currentUser = localStorage.getItem(USER_LS)
    if (currentUser === null){
        askForName();
    } else{
        // 값이 없을 경우
    }
}
























function init() {
    loadName();
}

init();